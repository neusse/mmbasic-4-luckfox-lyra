# MMBasic For Luckfox Lyra PicoCalc

This release bundle installs the prebuilt ARMv7 MMBasic binary and the runtime
files needed for the Luckfox Lyra PicoCalc target.

Install on the PicoCalc:

```sh
sh install-picocalc.sh
```

The installer writes:

- `/usr/local/bin/mmbasic`
- `/usr/local/bin/mmb4l-run-tests`
- `/usr/local/share/mmb4l`
- `/etc/directfbrc`
- `/usr/bin/mmbasic` and `/usr/bin/mmb4l-run-tests` symlinks

By default it also applies the proven PicoCalc display workaround:

```sh
chmod 666 /dev/fb0 /dev/tty0
```

Set `MMB4L_APPLY_DEVICE_PERMS=0` to skip that step. Set `MMB4L_RUN_SMOKE=0` to
skip the smoke test at the end of installation.

The test runner uses a 60 second timeout per BASIC test file. Set
`MMB4L_TEST_TIMEOUT=120` to allow slower tests, or `MMB4L_TEST_TIMEOUT=0` to
disable the timeout.

After installing, run:

```sh
mmb4l-run-tests
```