# MMBasic For Luckfox Lyra PicoCalc

This release bundle installs the prebuilt ARMv7 MMBasic binary and the runtime
files needed for the Luckfox Lyra PicoCalc target.

Install on the PicoCalc:

```sh
sh install-picocalc.sh
```

The installer writes:

- `/usr/local/bin/mmbasic`
- `/usr/local/bin/mmb4l-run-tests`
- `/usr/local/bin/mmb4l-check-basic`
- `/usr/local/share/mmb4l`
- `/usr/bin/mmbasic`, `/usr/bin/mmb4l-run-tests`, and
  `/usr/bin/mmb4l-check-basic` symlinks

The installer does not change device permissions by default. If running as a
non-root user, verify access to `/dev/fb0`, `/dev/tty0`, and
`/dev/input/event0`. For a quick development-only test:

```sh
chmod 666 /dev/fb0 /dev/tty0 /dev/input/event0
```

Set `MMB4L_APPLY_DEVICE_PERMS=1` to have the installer apply that workaround.
Set `MMB4L_RUN_SMOKE=0` to skip the smoke test at the end of installation.

The test runner uses a 60 second timeout per BASIC test file. Set
`MMB4L_TEST_TIMEOUT=120` to allow slower tests, or `MMB4L_TEST_TIMEOUT=0` to
disable the timeout.

After installing, run:

```sh
mmb4l-run-tests
```

To scan a directory of BASIC programs for likely compatibility problems:

```sh
mmb4l-check-basic /mnt/sdcard/pico2w/mmbasic
```

Interactive use and graphics behavior are documented in
`docs/picocalc-repl-usage.md`.